﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Dynamic;
using Microsoft.AspNetCore.Authorization;
using Unabiz1.Models;
using Microsoft.EntityFrameworkCore;
using System.Security;

// For more information on enabling MVC for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace Unabiz1.Controllers
{
    public class UsersController : Controller
    {
        private AppDbContext _dbContext;

        public UsersController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        // TODO P08 1-3: Create constructor to receive dbContext and initialize the _dbContext variable

        

        [Authorize]
        public IActionResult Index()
        {
            // TODO P08 1-5: Set dbs to property dbSet for users
            DbSet<Users> dbs = _dbContext.Users;

            // TODO P08 1-6: Set model to all records of users  - use dbs.ToList()
            List<Users> model = dbs.ToList();

            // TODO P08 1-7: Pass model to view
            return View(model);
        }

        [Authorize(Roles ="Admin")]
        public IActionResult Create()
        {
            // TODO P08 2-2: Use ToList<Pokedex> to retrieve all pokedex and then use LINQ query to project to a List<dynamic> with 2 properties value and text
            // where value is Id and text is Name and pass the list to the view through ViewData
            DbSet<Users> dbs = _dbContext.Users;

            var user = dbs.ToList<Users>().OrderBy(p => p.Name).Select(
                p =>
                {
                    dynamic d = new ExpandoObject();
                    d.value = p.Id;
                    d.text = p.Name;
                    return d;
                }

                )
                .ToList<dynamic>();

            ViewData["user"] = user;

            return View();
        }

        [Authorize(Roles = "Admin")]
        [HttpPost]
        // TODO P08 2-3: Change the data type of mugOrder parameter from dynamic to Users
        public IActionResult Create(Users user)
        {
            if (ModelState.IsValid)
            {
                // TODO P08 2-4: Add new user to database using _dbContext and display appropriate message  
                DbSet<Users> dbs = _dbContext.Users;

                dbs.Add(user);

                if (_dbContext.SaveChanges() == 1)
                {
                    TempData["Msg"] = "New User Added";
                }

                else
                {
                    TempData["Msg"] = "Failed To Update Database";
                }
            }
            else
            {
                TempData["Msg"] = "Invalid information entered";
            }

            return RedirectToAction("Index");
        }
    }
}
