﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Unabiz1.Models;
using Microsoft.EntityFrameworkCore;
using System.Data.Common;
using System.Data.SqlClient;
using Microsoft.AspNetCore.Authorization;

namespace Unabiz1.Controllers
{
    public class HomeController : Controller
    {
        

        [Authorize]
        public IActionResult Index()
        {
            return View();
        }
    }
}