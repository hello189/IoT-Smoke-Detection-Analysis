﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Unabiz1.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.AspNetCore.Authorization;

// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace Unabiz1.Controllers
{
    public class AdminController : Controller
    {
        private AppDbContext _dbContext;

        public AdminController(AppDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        [Authorize]
        public IActionResult Index()
        {
            DbSet<Admin> dbs = _dbContext.Admin;
            List<Admin> model = dbs.OrderBy(a => a.Id)
                                           .ThenBy(a => a.Name)
                                           .ToList();
            return View(model);
        }

        [Authorize]
        public IActionResult Create(string Id)
        {
            DbSet<Admin> dbs = _dbContext.Admin;
            Admin user = dbs.Where(p => p.Id == Id)
                                 .FirstOrDefault();
            if (user == null)
            {
                TempData["Msg"] = String.Format("User {0} not found!", Id);
                return RedirectToAction("Index");
            }
            else
            {
                ViewData["user"] = user;
                Admin model = new Admin();
                model.Id = user.Id;
                model.AppDate = DateTime.Today;
                return View(model);
            }
        }

        //[HttpPost]
        //[Authorize]
        //public IActionResult Create(Appointment newAppointment)
        //{
        //    DbSet<Appointment> dbs = _dbContext.Appointment;
        //    dbs.Add(newAppointment);

        //    int result = _dbContext.SaveChanges();
        //    if (result == 1)
        //    {
        //        TempData["Msg"] = String.Format("New appointment created for {0} created!", newAppointment.PatientId);
        //    }
        //    else
        //    {
        //        TempData["Msg"] = String.Format("Failed to create new appointment for {0}!", newAppointment.PatientId);
        //    }
        //    return RedirectToAction("Index");
        //}

        //[Authorize]
        //public IActionResult SearchByPatientId(string Id)
        //{
        //    DbSet<Appointment> dbs = _dbContext.Appointment;
        //    List<Appointment> model = dbs.Where(a => a.PatientId == Id)
        //                                 .OrderBy(a => a.AppDate)
        //                                 .ThenBy(a => a.PatientId)
        //                                 .ToList();
        //    ViewData["byPatient"] = true;
        //    ViewData["patientId"] = Id;
        //    return View(model);
        //}

        //[Authorize]
        //public IActionResult GetApptByPatientId(string Id)
        //{
        //    DbSet<Appointment> dbs = _dbContext.Appointment;
        //    IQueryable<Appointment> q = from a in dbs
        //                                where a.PatientId == Id
        //                                orderby a.AppDate, a.PatientId
        //                                select a;
        //    List<Appointment> model = dbs.Where(a => a.PatientId == Id)
        //                                 .OrderBy(a => a.AppDate)
        //                                 .ThenBy(a => a.PatientId)
        //                                 .ToList();
        //    ViewData["byPatient"] = true;
        //    return PartialView("_Appointments", model);
        //}

        [Authorize]
        public IActionResult SearchByDate(string Id)
        {
            DateTime appt;
            List<Readings> model;
            if (Utils.TryParseDate(Id, out appt))
            {
                DbSet<Readings> dbs = _dbContext.Readings;
                model = dbs.Where(a => a.AppDate == appt)
                                        .OrderBy(a => a.Id)
                                        .ToList();
            }
            else
            {
                model = new List<Readings>();
            }

            ViewData["byUser"] = false;
            ViewData["apptDate"] = Id;
            return View(model);
        }

        [Authorize]
        public IActionResult GetApptByDate(string Id)
        {
            DateTime appt;
            List<Readings> model;
            if (Utils.TryParseDate(Id, out appt))
            {
                DbSet<Readings> dbs = _dbContext.Readings;
                model = dbs.Where(a => a.AppDate == appt)
                           .OrderBy(a => a.PatientId)
                           .ToList();
            }
            else
            {
                model = new List<Readings>();
            }

            ViewData["byPatient"] = false;
            return PartialView("_Readings", model);
        }
    }
}
