﻿using System;
using System.Collections.Generic;

namespace Unabiz1.Models
{
    public partial class Readings
    {
        //to be updated and changed
        public int Id { get; set; }
        public string PatientId { get; set; }
        public DateTime AppDate { get; set; }
        public string DoctorId { get; set; }

        //public virtual Patient Patient { get; set; }
    }
}
