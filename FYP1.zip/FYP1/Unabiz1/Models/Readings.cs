﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Unabiz1.Models
{
    public class Readings
    {
        public string DataDate { get; set; }
        public string DeviceId { get; set; }
        public byte[] Temp { get; set; }
        public string Hum { get; set; }
    }
}
