﻿using System;
using System.Collections.Generic;

namespace Unabiz1.Models
{
    public partial class Users
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public byte[] Password { get; set; }
        public string Role { get; set; }
        //public DateTime AppDate { get; set; }
    }
}
