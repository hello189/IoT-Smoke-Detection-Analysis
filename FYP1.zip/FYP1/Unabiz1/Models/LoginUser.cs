﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace Unabiz1.Models
{
    public class LoginUser
    {


        [Required(ErrorMessage = "Id cannot be empty!")]
        public string Id { get; set; }

        [Required(ErrorMessage = "Empty password not allowed!")]
        [DataType(DataType.Password)]
        public string Password { get; set; }

        
        public string UserName { get; set; }


    }
}

